#ifndef _APP_H_
#define _APP_H_
#include "ELL_LIB.h" 

void flash(uint16_t interval, uint8_t count);

void effect_switch(uint8_t channel);
void effect_alternate(uint16_t interval);
void effect_blink(uint8_t channel, uint16_t elapse_on, uint16_t interval);
void effect_breath(uint8_t channel, uint16_t interval);

#endif