/*-----------------------------------------------------------------------
|                            FILE DESCRIPTION                           |
-----------------------------------------------------------------------*/
/*----------------------------------------------------------------------
  - File name     : main.c
  - Author        : zeweni
  - Update date   : 2020.01.11
  -	Copyright(C)  : 2020-2021 zeweni. All rights reserved.
-----------------------------------------------------------------------*/
/*------------------------------------------------------------------------
|                            COPYRIGHT NOTICE                            |
------------------------------------------------------------------------*/
/*
 * Copyright (C) 2021, zeweni (17870070675@163.com)

 * This file is part of 8051 ELL low-layer libraries.

 * 8051 ELL low-layer libraries is free software: you can redistribute 
 * it and/or modify it under the terms of the Apache-2.0 License.

 * 8051 ELL low-layer libraries is distributed in the hope that it will 
 * be useful,but WITHOUT ANY WARRANTY; without even the implied warranty 
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
 * Apache-2.0 License License for more details.

 * You should have received a copy of the Apache-2.0 License.8051 ELL 
 * low-layer libraries. If not, see <http://www.apache.org/licenses/>.
**/
/*-----------------------------------------------------------------------
|                               INCLUDES                                |
-----------------------------------------------------------------------*/
#include "main.h"
#include "app.h"
#include "../../mcu_sdk/wifi.h"

/*-----------------------------------------------------------------------
|                                 DATA                                  |
-----------------------------------------------------------------------*/
#define KEY1 P30
#define KEY2 P31

uint8_t mode = 0;
uint8_t channel = 0;
uint16_t interval = 0;
/*-----------------------------------------------------------------------
|                               FUNCTION                                |
-----------------------------------------------------------------------*/

/**
  * @name    main
  * @brief   main program
  * @param   None
  * @return  None
***/
int main(void) {
	uint8_t connecting = 0;
	STC8x_System_Init();
	wifi_protocol_init();
	while (1) {
		wifi_uart_service();
		if (KEY1 == 0) {
			DELAY_Set_Ms(20);
			if (KEY1 == 0) {
				mode = ++mode & 0x03;
				mode |= 0x80;
				interval = 0;
				if (KEY2 == 0) {
					DELAY_Set_Ms(3000);
					if (KEY2 == 0) {
						mcu_set_wifi_mode(SMART_CONFIG);
						connecting = 1;
					}
				}
				flash(100, 3);
			}
		}
		if (KEY2 == 0) {
			DELAY_Set_Ms(20);
			if (KEY2 == 0) {
				mode |= 0x80;
				channel = ++channel & 0x03;
				DELAY_Set_Ms(500);
			}
		}
		if (mode & 0x80) {
			switch (mode & 0x0F) {
			case 0: effect_switch(channel); break;
			case 1: if (interval == 0) interval = 1000; effect_alternate(interval); break;
			case 2: if (interval == 0) interval = 1000; effect_blink(channel, 50, interval); break;
			case 3: if (interval == 0) interval= 4000; effect_breath(channel, interval); break;
			}
			if ((mode & 0x40) == 0x00) {
				mcu_dp_enum_update(DPID_CHANNEL, channel);
				mcu_dp_enum_update(DPID_MODE, mode & 0x0F);
				mcu_dp_value_update(DPID_INTERVAL, interval);
			}
			mode &= 0x0F;
		}
		if (connecting) {
			switch (mcu_get_wifi_work_state()) {
			case SMART_CONFIG_STATE:
			case AP_STATE:
			case SMART_AND_AP_STATE:
				flash(500, 1);
				break;
			case WIFI_CONNECTED:
				flash(500, 2);
				break;
			case WIFI_CONN_CLOUD:
				flash(500, 3);
				connecting = 0;
				break;
			}
			DELAY_Set_Ms(1000);
			effect_switch(0x00);
		}
	}
}

/*-----------------------------------------------------------------------
|                   END OF FLIE.  (C) COPYRIGHT zeweni                  |
-----------------------------------------------------------------------*/