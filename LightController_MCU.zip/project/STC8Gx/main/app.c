#include "app.h"
#include "main.h"

uint8_t select = 0;
uint8_t port = 0;
uint16_t arg1 = 0;
uint16_t arg2 = 0;
uint16_t arg3 = 0;
uint16_t elapse = 0;

/**
* Timer ISR
*/
void timer_interval_500us() {
	switch (select) {
	case 1:
		if (elapse >= arg1) {
			OUT1 = OUT2;
			OUT2 = !OUT2;
			elapse = 0;
		} else elapse += 1;
		break;
	case 2:
		if (elapse == arg1) {
			OUT1 = 0;
			OUT2 = 0;
			elapse += 1;
		} else if (elapse >= arg2) {
			OUT1 = port & 0x01;
			OUT2 = port & 0x02;
			elapse = 0;
		} else elapse += 1;
		break;
	case 3:
		if (arg3 == arg2) {
			OUT1 = 0;
			OUT2 = 0;
			arg3 += 1;
		} else if (arg3 >= 16) {
			OUT1 = port & 0x01;
			OUT2 = port & 0x02;
			arg3 = 0;
		} else arg3 += 1;
		if (elapse >= (arg1 << 5)) elapse = 0;
		else elapse += 1;
		if (elapse <= (arg1 << 4)) arg2 = elapse / arg1;
		else arg2 = 32 - elapse / arg1;
		break;
	default:
		break;
	}
}

/**
* OUT1 flash
*/
void flash(uint16_t interval, uint8_t count) {
	interval >>= 1;
	while (count > 0) {
		OUT1 = 1;
		DELAY_Set_Ms(interval);
		OUT1 = 0;
		DELAY_Set_Ms(interval);
		count -= 1;
	}
}

/**
* ON/OFF
*/
void effect_switch(uint8_t ch) {
	select = 0;
	OUT1 = ch & 0x01;
	OUT2 = ch & 0x02;
}

/**
* Exchange
*/
void effect_alternate(uint16_t interval) {
	select = 1;
	elapse = 0;
	arg1 = interval << 1;
}

/**
* Blink
*/
void effect_blink(uint8_t ch, uint16_t elapse_on, uint16_t interval) {
	select = 2;
	elapse = 0;
	port = ch;
	arg1 = elapse_on << 1;
	arg2 = interval << 1;
}

/**
* Breath
*/
void effect_breath(uint8_t ch, uint16_t interval) {
	select = 3;
	elapse = 0;
	port = ch;
	arg1 = interval >> 4;
	arg2 = 1;
	arg3 = 0;
}